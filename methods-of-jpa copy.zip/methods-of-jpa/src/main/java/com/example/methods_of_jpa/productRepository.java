package com.example.methods_of_jpa;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;


public interface productRepository extends JpaRepository<product,Integer> {
    Optional<product>findByProductName(String name);


    List<product>findAllByProductPriceBetween(double startPrice,double endPrice);

    
}
